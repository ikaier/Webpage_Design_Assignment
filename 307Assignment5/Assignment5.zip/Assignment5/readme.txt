The page works well on both Chrome and Safari.
Need internet access to get online font "Myriad-pro" from Adobe type kit

